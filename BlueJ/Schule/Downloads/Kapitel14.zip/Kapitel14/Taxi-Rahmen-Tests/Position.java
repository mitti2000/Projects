
/**
 * Modelliert eine Position in einer Stadt.
 * 
 * @author David J. Barnes und Michael K�lling
 * @version 31.07.2011
 */
public class Position
{
    /**
     * Konstruktor f�r Objekte der Klasse Position
     */
    public Position()
    {
    }
}
