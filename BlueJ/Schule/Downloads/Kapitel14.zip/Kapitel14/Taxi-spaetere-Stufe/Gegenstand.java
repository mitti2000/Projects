/**
 * Ein Gegenstand mit einer Position in einer Stadt.
 * 
 * @author David J. Barnes und Michael K�lling
 * @version 31.07.2011
 */

public interface Gegenstand
{
    public Position gibPosition();
}
