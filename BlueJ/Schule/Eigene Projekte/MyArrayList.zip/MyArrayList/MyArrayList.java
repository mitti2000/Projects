
/**
 * Beschreiben Sie hier die Klasse MyArrayList.
 * 
 * @author Thomas Mittermair 
 * @version August 2016
 */
public class MyArrayList
{
    //ausschliesslich Arrays
    //Erweitert sich um die Hälfte der bereits gespeicherten Elemente sobald der vorletze Platz belegt ist
    //Array hat keine Löcher

    private Person[] personen;

    //Konstruktor erstellt ein neues Personen Array mit 2 Plätzen
    public MyArrayList(){
        personen = new Person[2];
    }

    //Rezise Array wenn vorletzter Platz belegt
    private void resize(){
        int anzahlFreiePlaetze = 0;
        int anzahlBelegtePlaetze = 0;
        Person[] tempPersonen;
        
        for(int i=personen.length-1; i==0; i--){
            if(personen[i]==null) anzahlFreiePlaetze++;
        }
        
        anzahlBelegtePlaetze = personen.length-anzahlFreiePlaetze;
        
        if(anzahlFreiePlaetze<=1){
            if(anzahlBelegtePlaetze>1)tempPersonen = new Person[personen.length + (anzahlBelegtePlaetze/2)];
            else if(anzahlBelegtePlaetze==1) tempPersonen = new Person[personen.length + 1];
            else tempPersonen = new Person[2];
            
            for(int j=0; j<personen.length; j++){
                tempPersonen[j] = personen[j];
            }
            
            personen = new Person[tempPersonen.length];
            
            for (int k=0; k<tempPersonen.length; k++){
                personen[k] = tempPersonen[k];
            }
        }
        
        /*int counter = 0;
        personenTemp = new Person[personen.length];
        for(int i=0; i<personen.length; i++){
            if (personen[i]!=null) counter++;
        }

        if(personen.length-counter<=1){
            //System.arraycopy(copyfrom, startingPosition, copyTo, startingPosition, anzahlElemente) wäre möglich
            for(int i=0; i<personen.length; i++){
                personenTemp[i] = personen[i];
            }

            personen = new Person[counter+(counter/2)];

            for(int j=0; j<personenTemp.length; j++){
                personen[j] = personenTemp[j];
            }
        }*/
    }

    //Räumt Array auf so das keine leeren Plätze vorhanden sind
    private void cleanup(){
        boolean isClean = false;
        Person tempPerson;
        int belegtePositionen = 0;
        
        for(int j=0; j<personen.length; j++){
            if(personen[j] != null) belegtePositionen++;
        }
        
        while(!isClean && belegtePositionen>0){
            isClean = true;

            for(int i=0; i<(personen.length-1);i++){
                if(personen[i]==null){
                    tempPerson=personen[i];
                    personen[i]=personen[i+1];
                    personen[i+1]=tempPerson;
                    isClean=false;
                }
            }
        }
    }

    public boolean add(Person p){ //erlaubt es neue Personen referenzen zu speichern. Person wird an erster der letzten leeren Stellen eingefügt
        boolean found = false;
        int position = -1;
        cleanup();

        //while(!found){
            for(int i=personen.length-2;i==0;i--){
                if(!found && personen[i]!=null && personen[i+1]==null) { //erste Position wo ein Element drin ist von hinten angefangen
                    found=true;
                    position = i+1;
                    found = true;
                }
            }
            if(!found && position == -1){
                position = 0;
            }
        //}

        if (position>-1) {
            personen[position]=p;
            resize();
            return true;
        }

        else return false;        
    }

    public boolean add(int index, Person p){//Person an bestimmer stelle speichern
        cleanup();
        if(personen[index]==null && index<personen.length && index>-1){
            personen[index]=p;
            resize();
            return true;
        }

        else if(personen[index]!=null && index<personen.length && index>-1){
            for(int i=personen.length-2;i==index; i--){
                personen[i+1] = personen[i];
                personen[i] = null;
            }

            personen[index]=p;
            resize();
            return true;
        }

        else return false;
    }

    public Person remove(int index){ //Person an bestimmter Stelle löschen
        if(personen[index]!=null){
            Person tempPerson;
            tempPerson = personen[index];
            personen[index]=null;
            cleanup();
            return tempPerson;
        }
        else return null;
    }

    public boolean remove(Person p){//löscht das erste Element aus der Sammlung das der Person p entspricht. Die folgenden Elemente rücken nach
        Person tempPerson=null;
        boolean personGefunden = false;
        int index = 0;
        if(p!=null){
            while(!personGefunden && index<personen.length){
                if(personen[index].equals(p) && !personGefunden){
                    personen[index] = null;
                    personGefunden=true;
                }
                index++;
            }
        }
        cleanup();
        return personGefunden;
    }

    public void clear(){ //löscht alle Elemente aus der Sammlung
        for(int i =0; i<personen.length; i++){
            personen[i] = null;
            trimToSize();
        }
    }

    public Person get(int index){ // liefert Person an index zurück
        if(index>-1 && index<personen.length){
            return personen[index];
        }
        else return null;
    }

    public int size(){//liefert die Anzahl gespeicherter Elemente
        return personen.length;
    }

    public Person set(int index, Person p){ //ersetzt ein Objekt an einer bestimmten Person und gibt referenz zurück
        Person tempPerson=null;
        if(index>-1 && index<personen.length){
            tempPerson = personen[index];
            personen[index] = p;
        }
        
        return tempPerson;
    }

    public Person[] toArray(){ //gibt alle Elemente als Array zurück. Wenn keine Elemente vorhanden return ist ein leeres Array mit 0 Plätzen;
        Person[] tempPersonen;
        int counter = 0;
        
        for(int i=0; i<personen.length; i++){
            if(personen[i]!=null){
                counter++;
            }
        }
        
        if(counter>0){
            tempPersonen = new Person[counter];
            for(int i=0; i<counter;i++){
                tempPersonen[i] = personen[i];
            }
        }
        else tempPersonen = new Person[0];
        
        return tempPersonen;
    }

    public void trimToSize(){//schneidet das Array auf belegte Elemente und 2 leere
        Person[] tempPersonen;
        
         int counter = 0;
        
        for(int i=0; i<personen.length; i++){
            if(personen[i]!=null){
                counter++;
            }
        }
        
        if(counter>0){
            tempPersonen = new Person[counter];
            for(int i=0; i<counter;i++){
                tempPersonen[i] = personen[i];
            }
        }
        else tempPersonen = new Person[0];
        
        personen = tempPersonen;
    }
}
