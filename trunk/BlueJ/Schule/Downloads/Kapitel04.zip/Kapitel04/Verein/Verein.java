/**
 * Speichert Details �ber Vereinsmitgliedschaften.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Verein
{
    // Definieren Sie alle notwendigen Datenfelder hier...
    
    /**
     * Konstruktor f�r Objekte der Klasse Verein
     */
    public Verein()
    {
        // Initialisieren Sie die Datenfelder hier...
        
    }

    /**
     * F�ge ein neues Mitglied in die Mitgliederliste ein.
     * @param mitglied Infos �ber das einzuf�gende Mitglied.
     */
    public void beitreten(Mitgliedschaft mitglied)
    {
    }

    /**
     * @return die Anzahl der Mitglieder (Mitgliedschaft-Objekte)
     *         in diesem Verein.
     */
    public int anzahlMitglieder()
    {
        return 0;
    }
}
