
public class __SHELL1 extends bluej.runtime.Shell {
public static void run() throws Throwable {
final bluej.runtime.BJMap __bluej_runtime_scope = getScope("C:\\Beispiele\\Kapitel12\\Adressbuch-V2T");
final AdressbuchDemo adressbu1 = (AdressbuchDemo)__bluej_runtime_scope.get("adressbu1");


adressbu1.zeigeSchnittstelle();

}}
